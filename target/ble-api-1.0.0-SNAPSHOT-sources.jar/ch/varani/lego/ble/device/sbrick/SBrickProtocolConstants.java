package ch.varani.lego.ble.device.sbrick;

/**
 * Constants for the SBrick BLE remote control protocol (Rev. 26, 2020-10-28).
 *
 * <p>Reference: SBrick BLE Protocol PDF, Vengit Limited.
 *
 * <p><strong>Note on the Remote Control Commands UUID:</strong> the official PDF
 * omits a leading zero. The correct UUID is {@link #REMOTE_CONTROL_COMMANDS_UUID}.
 */
public final class SBrickProtocolConstants {

    // =========================================================================
    // Discovery
    // =========================================================================

    /** BLE manufacturer company ID for Vengit Limited (little-endian: 0x0198). */
    public static final int MANUFACTURER_ID = 0x0198;

    // =========================================================================
    // Advertisement data record types
    // =========================================================================

    /** Ad record type: product ID, HW major/minor, FW major/minor. */
    public static final int AD_RECORD_PRODUCT_INFO = 0x00;

    /** Ad record type: device identifier (6-byte string). */
    public static final int AD_RECORD_DEVICE_IDENTIFIER = 0x02;

    /** Ad record type: security status. */
    public static final int AD_RECORD_SECURITY_STATUS = 0x03;

    /** Ad record type: thermal protection status. */
    public static final int AD_RECORD_THERMAL_PROTECTION = 0x05;

    /** Ad record type: voltage measurement (12-bit ADC + 4-bit channel). */
    public static final int AD_RECORD_VOLTAGE = 0x06;

    // =========================================================================
    // GATT Service UUIDs
    // =========================================================================

    /** UUID of the SBrick Remote Control GATT service. */
    public static final String REMOTE_CONTROL_SERVICE_UUID =
            "4dc591b0-857c-41de-b5f1-15abda665b0c";

    /** UUID of the OTA Firmware Update GATT service. */
    public static final String OTA_SERVICE_UUID =
            "1d14d6ee-fd63-4fa1-bfa4-8f47b42119f0";

    // =========================================================================
    // GATT Characteristic UUIDs
    // =========================================================================

    /**
     * UUID of the Remote Control Commands characteristic.
     *
     * <p>All commands are written to this characteristic. Write Without Response.
     *
     * <p><strong>Important:</strong> the official PDF lists this UUID without the
     * leading zero. The correct full UUID (with leading zero) is used here.
     */
    public static final String REMOTE_CONTROL_COMMANDS_UUID =
            "02b8cbcc-0e25-4bda-8790-a15f53e6010f";

    /** UUID of the OTA Control characteristic (write {@code 0x03} to reboot into DFU). */
    public static final String OTA_CONTROL_UUID =
            "f7bf3564-fb6d-4e53-88a4-5e37e0326063";

    /** UUID of the OTA Data characteristic (write 20- or 55-byte chunks). */
    public static final String OTA_DATA_UUID =
            "984227f3-34fc-4045-a5d0-2c581f81a153";

    // =========================================================================
    // Motor channels
    // =========================================================================

    /** Channel A (port index 0x00). */
    public static final int CHANNEL_A = 0x00;

    /** Channel C (port index 0x01). */
    public static final int CHANNEL_C = 0x01;

    /** Channel B (port index 0x02). */
    public static final int CHANNEL_B = 0x02;

    /** Channel D (port index 0x03). */
    public static final int CHANNEL_D = 0x03;

    // =========================================================================
    // Motor direction
    // =========================================================================

    /** Direction: clockwise. */
    public static final int DIRECTION_CLOCKWISE = 0x00;

    /** Direction: counter-clockwise. */
    public static final int DIRECTION_COUNTER_CLOCKWISE = 0x01;

    // =========================================================================
    // Commands
    // =========================================================================

    /** Command ID: Brake one or more channels. Format: {@code [0x00][ch1][ch2]...} */
    public static final int CMD_BRAKE = 0x00;

    /**
     * Command ID: Drive one or more channels.
     * Format: {@code [0x01][channel][direction][power]} repeated per channel.
     * Power range: 0x00 (freewheel) – 0xFF (full).
     */
    public static final int CMD_DRIVE = 0x01;

    /**
     * Command ID: Query ADC channel.
     * Format: {@code [0x0F][channel: 0x00–0x09]}.
     * Returns 2 bytes little-endian: bits 15–4 = 12-bit ADC, bits 3–0 = channel.
     */
    public static final int CMD_QUERY_ADC = 0x0F;

    /**
     * Command ID: Set watchdog timeout.
     * Format: {@code [0x0D][timeout]} where timeout is in units of 0.1 s.
     * {@code 0x00} disables the watchdog. Default: {@code 0x05} (0.5 s).
     */
    public static final int CMD_SET_WATCHDOG = 0x0D;

    /**
     * Command ID: Get watchdog timeout.
     * Format: {@code [0x0E]}. Returns 1 byte.
     */
    public static final int CMD_GET_WATCHDOG = 0x0E;

    // =========================================================================
    // ADC channel indices
    // =========================================================================

    /** ADC channel: battery voltage. */
    public static final int ADC_CHANNEL_BATTERY = 0x08;

    /** ADC channel: internal temperature. */
    public static final int ADC_CHANNEL_TEMPERATURE = 0x09;

    // =========================================================================
    // Voltage and temperature conversion factors
    // =========================================================================

    /**
     * Multiplier for converting a raw ADC battery reading to volts.
     *
     * <p>Formula: {@code V = (adc * ADC_VOLTAGE_MULTIPLIER) / ADC_VOLTAGE_DIVISOR}
     */
    public static final double ADC_VOLTAGE_MULTIPLIER = 0.83875;

    /** Divisor for the battery voltage formula. */
    public static final double ADC_VOLTAGE_DIVISOR = 127.0;

    /** Divisor for converting raw ADC temperature reading to degrees Celsius. */
    public static final double ADC_TEMPERATURE_DIVISOR = 0.13461;

    /** Offset subtracted after dividing to yield temperature in degrees Celsius. */
    public static final double ADC_TEMPERATURE_OFFSET = 160.0;

    // =========================================================================
    // Response codes
    // =========================================================================

    /** Response code: Success. */
    public static final int RESPONSE_SUCCESS = 0x00;

    /** Response code: Invalid data length. */
    public static final int RESPONSE_INVALID_DATA_LENGTH = 0x01;

    /** Response code: Invalid parameter. */
    public static final int RESPONSE_INVALID_PARAMETER = 0x02;

    /** Response code: No such command. */
    public static final int RESPONSE_NO_SUCH_COMMAND = 0x03;

    /** Response code: Authentication error. */
    public static final int RESPONSE_AUTH_ERROR = 0x05;

    /** Response code: Authentication needed. */
    public static final int RESPONSE_AUTH_NEEDED = 0x06;

    /** Response code: Thermal protection active. */
    public static final int RESPONSE_THERMAL_PROTECTION = 0x08;

    /** Response code: Wrong state. */
    public static final int RESPONSE_WRONG_STATE = 0x09;

    // =========================================================================
    // Quick Drive speed encoding
    // =========================================================================

    /**
     * Quick Drive magnitude: brake (for direction 0).
     * In the Quick Drive notification, {@code 0x00} means brake.
     */
    public static final int QUICK_DRIVE_BRAKE_CW = 0x00;

    /**
     * Quick Drive magnitude: brake (for direction 1).
     * In the Quick Drive notification, {@code 0x01} means brake.
     */
    public static final int QUICK_DRIVE_BRAKE_CCW = 0x01;

    /** Quick Drive magnitude: zero speed. */
    public static final int QUICK_DRIVE_ZERO_SPEED = 0x02;

    /** Quick Drive magnitude: full speed. */
    public static final int QUICK_DRIVE_FULL_SPEED = 0xFE;

    /**
     * Bit mask for extracting the magnitude (bits 7–1) from a Quick Drive byte.
     */
    public static final int QUICK_DRIVE_MAGNITUDE_MASK = 0xFE;

    /**
     * Bit mask for extracting the direction (bit 0) from a Quick Drive byte.
     * {@code 0} = clockwise, {@code 1} = counter-clockwise.
     */
    public static final int QUICK_DRIVE_DIRECTION_MASK = 0x01;

    // =========================================================================
    // Constructor
    // =========================================================================

    /**
     * Private constructor — this is a constants class with no instances.
     */
    private SBrickProtocolConstants() {
        throw new AssertionError("SBrickProtocolConstants must not be instantiated");
    }
}
